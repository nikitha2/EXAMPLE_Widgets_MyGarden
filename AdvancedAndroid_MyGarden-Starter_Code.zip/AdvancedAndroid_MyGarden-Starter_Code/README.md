# My Garden
Android AppWidgets lesson

## The app
My Garden is a simple game that allows you to add plants to your garden and keep them alive by watering them on time.
The app illustrates the power of widgets and collection widgets by making it easier for the user to monitor and water their plants from the home screen

## Screenshots

![Screenshot1](screenshots/screen_1.png) ![Screenshot2](screenshots/screen_2.png) ![Screenshot3](screenshots/screen_3.png)
![Screenshot4](screenshots/screen_4.png) ![Screenshot5](screenshots/screen_5.png) 

## Image resources
https://pixabay.com/en/sapling-plant-growing-seedling-154734/
https://pixabay.com/en/cactus-cacti-plant-thorns-spiky-152378/
https://pixabay.com/en/the-background-background-design-352165/
